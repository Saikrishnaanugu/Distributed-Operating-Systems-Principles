extended_script_tests
=====

An OTP library

Build
-----

    $ rebar3 compile
