overlay_error_test
=====

An OTP application

Build
-----

    $ rebar3 compile
