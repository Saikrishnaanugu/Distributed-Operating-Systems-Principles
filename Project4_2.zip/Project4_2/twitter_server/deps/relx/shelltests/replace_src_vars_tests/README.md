replace_os_vars_tests
=====

An OTP library

Build
-----

    $ rebar3 compile
