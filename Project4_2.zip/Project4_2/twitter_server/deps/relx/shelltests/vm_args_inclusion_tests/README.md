vm_args_inclusion_tests
=====

An OTP library

Build
-----

    $ rebar3 compile
