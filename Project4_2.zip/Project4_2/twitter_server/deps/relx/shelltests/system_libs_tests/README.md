system_libs_tests
=====

An OTP application

Build
-----

    $ rebar3 compile
