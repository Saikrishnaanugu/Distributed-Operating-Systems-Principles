force_nodetool_tests
=====

An OTP application

Build
-----

    $ rebar3 compile
