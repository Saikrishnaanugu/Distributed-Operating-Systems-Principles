check_undefined_test
=====

An OTP application

Build
-----

    $ rebar3 compile
